<template lang="html">
  <div class="zlbg">
    <div class="middle-top mb-2" >
       <div class="middle">
        <div class="alltop"><img src="../../../assets/img/query.png"/></div>
          <div class="inputcent">
              <el-row align="center"   :gutter="2" >
                <el-col span="4" class="input-item">
                </el-col>
                <el-col span="20" class="input-item">

                  <el-input placeholder=""   class="yy-input-all" ></el-input>
                  <img src="../../../assets/img/query1.png"/>
                  <img src="../../../assets/img/query2.png"/>
                </el-col>

              </el-row>
           </div>
        </div>
    </div>

    <div class="middle" >
      adasdfasdfsf
    </div>
    </div>
  </div>
</template>
<script>

</script>

<style scoped>
.alltop{text-align: center; height: 140px;}
.inputcent{height: 50px;text-align: center;}
.yy-input-all{ width: 820px;border: 3px #4BC39F solid; font-size: 16px;}
</style>
