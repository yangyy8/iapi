<template lang="html">
  <div class="eventbjsj">
    <div class="middle mb-6">
        <el-row type="flex">
          <el-col :span="20" class="pr-20">
            <el-row align="center" :gutter="2">
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">证件号：</span>
                <el-input v-model="pd.passportno" placeholder="请输入内容" size="small" clearable class="input-input"></el-input>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">航班号：</span>
                <el-input v-model="pd.fltno" placeholder="请输入内容" size="small" clearable class="input-input"></el-input>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">国籍/地区：</span>
                <el-select v-model="pd.nationality" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option
                    v-for="(item,ind) in nationAlone"
                    :key="ind"
                    :label="item.CODE+' - '+item.CNAME"
                    :value="item.CODE">
                  </el-option>
                </el-select>
              </el-col>
            </el-row>
            <el-collapse-transition>
            <el-row align="center" :gutter="2" v-if="moreShow">
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">姓名：</span>
                <el-input v-model="pd.name" placeholder="请输入内容" size="small" clearable class="input-input"></el-input>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">出生日期：</span>
                <div class="input-input t-flex t-date">
                  <el-date-picker
                   type="date" size="small" format="yyyy-MM-dd"
                   v-model="pd.birthday_start"
                   value-format="yyyyMMdd"
                   placeholder="开始时间" >
                  </el-date-picker>
                  <span class="septum">-</span>
                  <el-date-picker
                    type="date" size="small" format="yyyy-MM-dd"
                    v-model="pd.birthday_end"
                    value-format="yyyyMMdd"
                    placeholder="结束时间">
                  </el-date-picker>
                </div>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">航班日期：</span>
                <div class="input-input t-flex t-date">
                  <el-date-picker
                   type="datetime" size="small" format="yyyy-MM-dd HH:mm"
                   v-model="pd.fltnoDate_start"
                   value-format="yyyyMMddHHmmss"
                   placeholder="开始时间" >
                  </el-date-picker>
                  <span class="septum">-</span>
                  <el-date-picker
                    type="datetime" size="small" format="yyyy-MM-dd HH:mm"
                    v-model="pd.fltnoDate_end"
                    value-format="yyyyMMddHHmmss"
                    placeholder="结束时间">
                  </el-date-picker>
                </div>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">证件类型：</span>
                <el-select v-model="pd.passportType" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option
                    v-for="(item,ind) in docCode"
                    :key="ind"
                    :label="item.CODE+' - '+item.NAME"
                    :value="item.CODE">
                  </el-option>
                </el-select>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">历次风评：</span>
                <div class="input-input t-flex t-date">
                  <el-input-number size="small" v-model="pd.eachEvent_start"></el-input-number>
                  <span class="septum">-</span>
                  <el-input-number size="small" v-model="pd.eachEvent_end"></el-input-number>
                </div>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">命中模型：</span>
                <el-select v-model="pd.hit_mode" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option
                    v-for="(item,ind) in ModelHis"
                    v-if="item.MODEL_CODE"
                    :key="ind"
                    :label="item.MODEL_CODE+' - '+item.MODEL_JC"
                    :value="item.MODEL_CODE">
                  </el-option>
                </el-select>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">出入标识：</span>
                <el-select v-model="pd.flightType" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option label="I - 入境" value="I"></el-option>
                  <el-option label="O - 出境" value="O"></el-option>
                  <el-option label="A - 入出境" value="A"></el-option>
                </el-select>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">事件来源：</span>
                <el-select v-model="pd.centre_port" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option label="1 - 中心" value="1"></el-option>
                  <el-option label="2 - 口岸" value="2"></el-option>
                </el-select>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">口岸：</span>
                <el-select v-model="pd.port_name" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option
                    v-for="(item,ind) in airport"
                    v-if="item.DEPT_CODE"
                    :key="ind"
                    :label="item.DEPT_CODE+' - '+item.DEPT_JC"
                    :value="item.DEPT_CODE">
                  </el-option>
                </el-select>
              </el-col>
              <el-col :sm="24" :md="12"  :lg="8" class="input-item">
                <span class="input-text">当前状态：</span>
                <el-select v-model="pd.status" placeholder="请选择"  size="small" clearable filterable class="block input-input">
                  <el-option label="0 - 全部" value="0"></el-option>
                  <el-option label="1 - 未核查" value="1"></el-option>
                  <el-option label="2 - 已核查" value="2"></el-option>
                  <el-option label="3 - 已流转" value="3"></el-option>
                  <el-option label="4 - 已归档" value="4"></el-option>
                </el-select>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">推送人：</span>
                <el-input v-model="pd.change_people" placeholder="请输入内容" size="small" clearable class="input-input"></el-input>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">处理人：</span>
                <el-input v-model="pd.processor_people" placeholder="请输入内容" size="small" clearable class="input-input"></el-input>
              </el-col>
              <el-col :sm="24" :md="12" :lg="8" class="input-item">
                <span class="input-text">本事件核查次数：</span>
                <el-input v-model="pd.checkNumber" placeholder="请输入内容" size="small" clearable class="input-input"></el-input>
              </el-col>
            </el-row>
            </el-collapse-transition>
          </el-col>
          <el-col :span="2" class="down-btn-area">
            <el-button type="text" size="small" @click="moreShow=true" v-if="!moreShow">高级查询 ﹀</el-button>
            <el-button type="text" size="small" @click="moreShow=false" v-if="moreShow">收起 ︿</el-button>
          </el-col>
          <el-col :span="2" class="down-btn-area">
            <el-button type="success" size="small" @click="pd.type='0';getList(CurrentPage,pageSize,pd)">查询</el-button>
            <el-button type="primary" plain size="small"  class="mt-15" @click="reset" v-if="moreShow">重置</el-button>
          </el-col>
        </el-row>
    </div>
    <div class="middle">
      <div class="ak-tab">
        <div class="ak-tabs">
          <div class="ak-tab-item hand" :class="{'ak-checked':pd.type=='0'}" @click="pd.type='0';getList(CurrentPage,pageSize,pd)">
            全部
          </div>
          <div class="ak-tab-item hand" :class="{'ak-checked':pd.type=='1'}" @click="pd.type='1';getList(CurrentPage,pageSize,pd)">
            未核查
          </div>
          <div class="ak-tab-item hand" :class="{'ak-checked':pd.type=='2'}" @click="pd.type='2';getList(CurrentPage,pageSize,pd)">
            已核查
          </div>
          <div class="ak-tab-item hand" :class="{'ak-checked':pd.type=='3'}" @click="pd.type='3';getList(CurrentPage,pageSize,pd)">
            已流转
          </div>
          <div class="ak-tab-item hand" :class="{'ak-checked':pd.type=='4'}" @click="pd.type='4';getList(CurrentPage,pageSize,pd)">
            已归档
          </div>

        </div>
      </div>
      <div class="ak-tab-pane" >
        <el-button type="primary" class="mr-5" plain size="small" @click="openGdTc" :disabled="isdisable" v-if="pd.type!=4">批量归档</el-button>
        <el-button type="primary" plain size="small" @click="openCzTc" :disabled="isdisable" v-if="pd.type!=4">批量事件处理</el-button>

        <el-table
          class="mt-10"
          ref="multipleTable"
          :data="tableData"
          border
          @selection-change="handleSelectionChange"
          style="width: 100%;">
          <el-table-column
           v-if="pd.type!=4"
           fixed
           width="40"
           type="selection">
          </el-table-column>
          <!-- <el-table-column
            label="事件编号"
            prop="serial"
            sortable
            width="101">
          </el-table-column> -->
          <el-table-column
            label="姓名"
            prop="name"
            sortable
            width="80"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="出入标识"
            prop="flightTypeName"
            sortable
            width="50">
          </el-table-column>
          <el-table-column
            label="性别"
            prop="genderName"
            sortable
            width="50"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="出生日期"
            prop="birthday"
            sortable
            width="101">
          </el-table-column>
          <el-table-column
            label="国籍地区"
            sortable
            prop="nationalityName"
            width="50"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="证件类型"
            prop="passportTypeName"
            sortable
            width="50"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="证件号"
            prop="passportno"
            sortable
            width="90"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <span class="tc-b hand" @click="$router.push({name:'DZDA',query:{nationality:scope.row.nationality,passportno:scope.row.passportno,grade:scope.row.grade,type:1}})">{{scope.row.passportno}}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="航班号"
            prop="fltno"
            sortable
            width="90"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="航班日期"
            prop="fltnoDate"
            sortable
            width="101">
          </el-table-column>

          <el-table-column
            label="命中模型"
            prop="hit_mode_gc"
            sortable
            width="90"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="命中规则"
            prop="hit_rule_name"
            sortable
            width="90"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="口岸"
            prop="port_name"
            sortable
            width="60"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="事件来源"
            width="50"
            sortable
            prop="centre_port">
          </el-table-column>
          <el-table-column
            label="风险等级"
            sortable
            width="145"
            prop="grade">
            <template slot-scope="scope">
              <el-rate :value="scope.row.grade" size="mini" disabled class="mb-9"></el-rate>
            </template>
          </el-table-column>
          <el-table-column
            label="处理人"
            prop="processor_peopleName"
            width="50"
            sortable
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="当前状态"
            prop="statusName"
            sortable
            width="63"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="核查次数"
            prop="checknumber"
            sortable
            width="50"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="最新核查结果"
            width="50"
            sortable
            prop="checkResult"
            :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column
            label="历次风评"
            sortable
            prop="eachevent">
            <template slot-scope="scope">
              <el-popover
                placement="top"
                width="400"
                trigger="click">
                <ul>
                  <li v-for="i in eachData" class="hand" style="line-height:32px" title="查看" @click="$router.push({name:'BJCLCX',query:{serial:i.SERIAL,grade:i.GRADE}})">
                    <span>  创建时间：{{i.CREATETIME}}</span>
                    <span>  口岸名称：{{i.PORT_NAME}}</span>
                    <span>  处理结果：{{i.PROCESSORRESULT}}</span>
                  </li>
                </ul>
                <div class="tc-b hand" title="查看详情" slot="reference" @click="queryEach(scope.row.serial,scope.row.nationality,scope.row.passportno)">{{scope.row.eachevent}}</div>
              </el-popover>

            </template>
          </el-table-column>
          <el-table-column
            label="操作"
            fixed="right"
            width="70">
            <template slot-scope="scope">
              <el-button type="text" class="a-btn" icon="el-icon-view" title="查看" @click="$router.push({name:'BJSJCK',query:{serial:scope.row.serial,grade:scope.row.grade,page:0}})"></el-button>
              <el-button type="text" class="a-btn" icon="el-icon-edit-outline"  title="处理" @click="$router.push({name:'BJSJCK',query:{serial:scope.row.serial,grade:scope.row.grade,status:scope.row.status,page:1,operation_type:1}})"></el-button>
            </template>
          </el-table-column>
        </el-table>

        <div class="middle-foot">
          <div class="page-msg">
            <div class="">
              共{{Math.ceil(TotalResult/pageSize)}}页
            </div>
            <div class="">
              每页
              <el-select v-model="pageSize" @change="pageSizeChange(pageSize)" placeholder="10" size="mini" class="page-select">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
              条
            </div>
            <div class="">
              共{{TotalResult}}条
            </div>
          </div>
          <el-pagination
            background
            @current-change="handleCurrentChange"
            :page-size="pageSize"
            layout="prev, pager, next"
            :total="TotalResult">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog title="批量事件处理" :visible.sync="czDialogVisible" width="640px" :before-close="handleClose">
      <el-form :model="czform" ref="czForm">
        <div class=" boder1 mb-15">
          <div class="f-bold mb-9">
            处理结果描述
          </div>
          <el-input
            class="mb-9"
            type="textarea"
            v-model="czform.processor_desc"
            :rows="3"
            placeholder="请输入描述意见">
          </el-input>
        </div>

        <div class="f-bold mb-9">
          处理结果
        </div>
        <el-row align="center" :gutter="2">
          <el-col  :sm="24" :md="12" :lg="12"  class="input-item">
            <span class="mr-5">处理结果 </span>
            <el-select v-model="czform.processorResult" filterable clearable placeholder="请选择"  size="small" class="input-input">
              <el-option label="1 - 排除嫌疑" value="1"></el-option>
              <el-option label="2 -  未能排除嫌疑，待进一步核查" value="2"></el-option>
              <el-option label="3 -  推送梅沙 " value="3"></el-option>

            </el-select>
          </el-col>
          <el-col  :sm="24" :md="12" :lg="12"  class="input-item"  v-show="user.dept_code=='B06'">
            <span  class="mr-5">流转至 </span>
            <el-select v-model="czform.change_port" filterable clearable placeholder="请选择"  size="small" class="input-input">
              <el-option
                v-for="(item,ind) in airport"
                v-if="item.DEPT_CODE"
                :key="ind"
                :label="item.DEPT_CODE+' - '+item.DEPT_JC"
                :value="item.DEPT_CODE">
              </el-option>
            </el-select>
          </el-col>

        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="czSave" size="small">确认</el-button>
        <el-button type="warning" @click="czDialogVisible=false" size="small">取消</el-button>

      </div>
    </el-dialog>
    <GDTC :gtitle="'批量归档'" :gvisible="gdDialogVisible" :garr="multipleSelection" :gtype="'1'" @gclose="gclose"></GDTC>
  </div>
</template>

<script>
import GDTC from './GDTC'
import { formatDate } from '@/assets/js/date.js'

export default {
  components:{GDTC},
  data(){
    return{
      user:{},
      tagData:{},
      moreShow:false,
      page: 0,
      multipleSelection:null,
      tableData:[],
      eachData:[],
      CurrentPage:1,
      pageSize:10,
      TotalResult:0,
      pd:{type:'0',status:'0',fltnoDate_start:'',fltnoDate_end:''},
      airport:null,
      docCode:null,
      nationAlone:null,
      ModelHis:null,
      isdisable:true,
      options:[
        {
          value:10,
          label:"10"
        },
        {
          value:20,
          label:"20"
        },
        {
          value:30,
          label:"30"
        }
      ],
      options2:[
        {
          value: '1',
          label: '入境',
          children:[
            {
              value: '1',
              label: '允许入境',
              children:[
                {
                  value: '1',
                  label: '排除嫌疑，允许入境',
                },
                {
                  value: '2',
                  label: '暂未排除嫌疑，允许入境',
                },
                {
                  value: '8',
                  label: '移交相关单位',
                }
              ]
            },
            {
              value: '2',
              label: '阻止入境',
              children:[
                {
                  value: '7',
                  label: '参考梅沙',
                }
              ]
            }
          ]
        },
        {
          value: '2',
          label: '出境',
          children:[
            {
              value: '3',
              label: '允许出境',
              children:[
                {
                  value: '3',
                  label: '排除嫌疑，允许出境',
                },
                {
                  value: '4',
                  label: '暂未排除嫌疑，允许出境',
                },

              ]
            },
            {
              value: '4',
              label: '阻止出境',
              children:[
                {
                  value: '7',
                  label: '参考梅沙',
                },
                {
                  value: '8',
                  label: '移交相关单位',
                }
              ]
            }
          ]
        },
        {
          value: '3',
          label: '过境',
          children:[
            {
              value: '5',
              label: '允许过境',
              children:[
                {
                  value: '5',
                  label: '排除嫌疑，允许过境',
                },
                {
                  value: '6',
                  label: '暂未排除嫌疑，允许过境',
                },
                {
                  value: '8',
                  label: '移交相关单位',
                }
              ]
            },
            {
              value: '6',
              label: '阻止过境',
              children:[
                {
                  value: '7',
                  label: '参考梅沙',
                },

              ]
            }
          ]
        }

      ],
      czDialogVisible:false,
      czform:{},
      gdDialogVisible:false,

    }
  },
  mounted(){
    let begin = new Date();
    // console.log(begin+24*60*60*1000)
    let end = new Date(begin.getTime()+24*60*60*1000);

    this.pd.fltnoDate_start= formatDate(begin, 'yyyyMMdd')+'000000';
    this.pd.fltnoDate_end= formatDate(end, 'yyyyMMdd')+'000000';

    this.queryAirport();
    this.queryNationalityAlone();
    this.queryDocCode();
    this.getRiskModelHisInfo();
    this.getUers();
  },
  activated(){
    this.getList(this.CurrentPage,this.pageSize,this.pd);
  },
  methods:{
    getUers(){
      this.$api.post('/manage-platform/sysUserInfoController/querySysUserInfo',{},
       r => {
        console.log(r)
        this.user=r.data;
      })
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      if(this.multipleSelection.length==0){
        this.isdisable=true;
      }else{
        this.isdisable=false;
      }
    },
    pageSizeChange(val) {
      this.getList(this.CurrentPage,val,this.pd);
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      this.getList(val,this.pageSize,this.pd);
      console.log(`当前页: ${val}`);
    },
    handleClose(done) {
      // this.czform={};
      done();
    },
    reset(){
      this.CurrentPage=1;
      this.pageSize=10;
      this.pd={type:'0',status:'0'};
      this.getList(this.CurrentPage,this.pageSize,this.pd);
    },
    queryAirport(){
      this.$api.post('/manage-platform/riskEventController/getDeptInfo',{},
       r => {
         if(r.success){
           this.airport=r.data;
         }
      })
    },

    queryNationalityAlone(){
      this.$api.post('/manage-platform/codeTable/queryNationality',{},
       r => {
         if(r.success){
           this.nationAlone=r.data;
         }
      })
    },
    queryDocCode(){
      this.$api.post('/manage-platform/cardAndVisaTypeController/queryDmDocCodeAndDmDocCodes',{},
       r => {
         if(r.success){
           this.docCode=r.data;
         }
      })
    },
    getRiskModelHisInfo(){
      this.$api.post('/manage-platform/riskEventController/getRiskModelHisInfo',{},
       r => {
         if(r.success){
           this.ModelHis=r.data;
         }
      })
    },
    getList(CurrentPage,showCount,pd){
      if(this.pd.fltnoDate_start||this.pd.fltnoDate_end){
        if(!(this.pd.fltnoDate_end&&this.pd.fltnoDate_start)){
          this.$message.error('请输入完整的航班日期区间！');
          return
        }
      }
      if(this.pd.birthday_start||this.pd.birthday_end){
        if(!(this.pd.birthday_end&&this.pd.birthday_start)){
          this.$message.error('请输入完整的出生日期区间！');
          return
        }
      }
      if(this.pd.eachEvent_start||this.pd.eachEvent_end){
        if(!(this.pd.eachEvent_end&&this.pd.eachEvent_start)){
          this.$message.error('请输入完整的历次风评区间！');
          return
        }
      }
      let p={
        "showCount": showCount,
        "currentPage": CurrentPage,
        "pd": pd
      }
      this.$api.post('/manage-platform/riskEventController/queryRiskEventInfo',p,
       r => {
         console.log(r)
         this.tableData=r.data.resultList;
         this.TotalResult=r.data.totalResult;
      })
    },
    queryEach(serial,nationality,passportno){
      let p={
        "pd": {
          "serial":serial,
      		"nationality":nationality,
      		"passportno":passportno
        }
      }
      this.$api.post('/manage-platform/riskEventController/queryEachRiskEventInfo',p,
       r => {
         this.eachData=r.data
      })
    },
    openCzTc(){
      this.czform={};
      this.czDialogVisible=true
    },
    czSave(){
      if(!this.czform.processor_desc){
        this.$message.error('请先填写处理结果描述！');
        return
      }else if(!this.czform.processorResult){
        this.$message.error('请选择处理结果！');
        return
      }
      let arr1=this.multipleSelection;
      let p={
        list:[]
      };
      let that=this;
      for(var i=0;i<arr1.length;i++){
        let a={
          "processorResult":that.czform.processorResult,
    			"change_port":that.czform.change_port,
    			"processor_desc":that.czform.processor_desc,
        	"processor_people":this.user.userId,
    			"serial":arr1[i].serial
        }
        p.list.push(a)
      }

      this.$api.post('/manage-platform/riskEventController/updateBatchDisposeEventInfo',p,
       r => {
         if(r.success){
           this.$message({
             message: '恭喜你，操作成功！',
             type: 'success'
           });
           this.czDialogVisible=false;
           this.getList(this.CurrentPage,this.pageSize,this.pd);

         }
      })
    },
    openGdTc(){
      this.gdDialogVisible=true;
    },
    gclose(data){
      console.log(data)
      this.gdDialogVisible=data;
      this.getList(this.CurrentPage,this.pageSize,this.pd);

    }
  }
}
</script>

<style scoped>
.cellClass{
  height: 32px;
  white-space:nowrap;
  text-overflow:ellipsis;
  overflow: hidden;
}

</style>
